# Sample CSV Schema

This is the expected format for the household budget input file.

## Minimal Schema (required columns only)

```csv
Date,Amount,Category,Description
2024-01-03,1850.00,Housing,Rent payment
2024-01-05,120.45,Food,Loblaws grocery run
2024-01-07,65.00,Transport,Gas fill-up
2024-01-10,15.99,Entertainment & subscriptions,Netflix
2024-01-12,500.00,Savings & investments,TFSA contribution
2024-01-14,89.00,Food,Dining out - Montana's
2024-01-18,210.00,Transport,Car insurance
2024-01-22,180.00,Housing,Hydro bill
```

## Extended Schema (with budget column)

```csv
Date,Amount,Category,Description,Budget
2024-01-03,1850.00,Housing,Rent payment,2000.00
2024-01-05,120.45,Food,Loblaws grocery run,600.00
2024-01-07,65.00,Transport,Gas fill-up,300.00
```

## Notes

- **Date**: ISO format preferred (`YYYY-MM-DD`), but Power Query handles most formats.
- **Amount**: Positive numbers assumed to be expenses. If your export uses negatives for
  debits, Power Query will handle this in Step 2.
- **Budget**: Optional. If present, should be the monthly budget for that category
  (repeated on every row for that category, or joined from a separate table).
- **Category**: Should match one of the 5 standard categories. Variations will be mapped
  during data prep.
