# Power BI DAX Measures & Layout Guide

## Data Model Setup

1. Load cleaned Excel/CSV into Power BI Desktop (Home → Get Data)
2. In Power Query, ensure:
   - Date column is type *Date*
   - Withdrawals/Deposits are type *Decimal Number*
   - Category is trimmed: `Text.Trim(Text.Proper([Category]))`
   - Add MonthYear: `Date.ToText([Date], "MMM yyyy")`
   - Add MonthSort: `Date.Year([Date]) * 100 + Date.Month([Date])`
   - Sort MonthYear by MonthSort column
3. Create a `_Measures` table: Home → Enter Data, name it `_Measures`, leave empty

## Core DAX Measures

```dax
Total Spend =
SUMX(Expenses, Expenses[Withdrawals])

Total Income =
SUMX(Expenses, Expenses[Deposits])

Net Balance =
[Total Income] - [Total Spend]

MoM Change =
VAR CurrentMonth = [Total Spend]
VAR PrevMonth =
    CALCULATE([Total Spend], DATEADD(Expenses[Date], -1, MONTH))
RETURN DIVIDE(CurrentMonth - PrevMonth, PrevMonth, 0)

Running Total Spend =
CALCULATE(
    [Total Spend],
    FILTER(ALL(Expenses[Date]), Expenses[Date] <= MAX(Expenses[Date]))
)

Category % of Total =
DIVIDE(
    [Total Spend],
    CALCULATE([Total Spend], ALL(Expenses[Category])),
    0
)

YTD Spend =
TOTALYTD([Total Spend], Expenses[Date])
```

## Recommended Dashboard Layout

```
┌─────────────────────────────────────────────────────────┐
│  [Slicer: MonthYear]         [Slicer: Category]          │
├──────────┬──────────┬──────────┬────────────────────────┤
│ Total    │ Total    │ Net      │ Avg Monthly             │
│ Income   │ Expenses │ Balance  │ Spend (Card)            │
│ (Card)   │ (Card)   │ (Card)   │                         │
├──────────┴──────────┴──────────┴────────────────────────┤
│  Income vs Expenses         │  Spend by Category         │
│  (Clustered Bar)            │  (Donut Chart)             │
│  X: MonthYear               │  Legend: Category          │
│  Series: Income, Expenses   │  Values: Total Spend       │
├─────────────────────────────┴────────────────────────────┤
│  Cumulative Spending YTD (Area/Line Chart)               │
│  X: Date, Y: Running Total Spend                         │
└─────────────────────────────────────────────────────────┘
```

## Formatting Tips

- Currency format: `$#,##0` for cards, `$#,##0.00` for tables
- Net Balance card: conditional colour — green if positive, red if negative
- Theme: Accessible Default or Executive (avoid dark backgrounds)
- Page name: rename to "Monthly Budget" in Pages pane
- Add MoM Change as tooltip on the trend chart
